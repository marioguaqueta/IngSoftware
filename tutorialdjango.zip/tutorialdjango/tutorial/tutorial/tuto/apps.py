from django.apps import AppConfig


class TutoConfig(AppConfig):
    name = 'tuto'
